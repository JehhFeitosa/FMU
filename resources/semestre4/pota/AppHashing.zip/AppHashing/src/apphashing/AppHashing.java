package apphashing;

public class AppHashing {

    public static void main(String[] args) {
        // Cria tabela hash
        int tamanhoTabela = 5;
        String[] tabelaHash = new String[tamanhoTabela];

        // Insere a chave na tabela hash
        String chave = "Joe Caputo";
        int posicao = h(chave, tamanhoTabela);

        // Verifica se houve colisão
        if (tabelaHash[posicao] != null) {
            tabelaHash[posicao] = chave;
        } else {
            // Encontrar nova posição (hashing linear)            
        }

        // Imprime a tabela hash completa
        for (int i = 0; i < tamanhoTabela; i++) {
            System.out.print("Posição: ");
            System.out.print(i);
            System.out.print("\t");
            System.out.print("Valor: ");
            System.out.println(tabelaHash[i]);
        }
    }

    public static int h(String chave, int n) {
        int tamanhoChave = chave.length();
        int[] pesos = geraPesos(tamanhoChave);
        int k = k(chave, pesos);
        return k % n;
    }

    private static int k(String chave, int[] pesos) {
        int soma = 0;
        for (int i = 0; i < chave.length(); i++) {
            soma = soma + ((int) chave.charAt(i)) * pesos[i];
        }
        return soma;
    }

    private static int[] geraPesos(int n) {
        int p[] = new int[n];
        java.util.Random rand = new java.util.Random();
        for (int i = 0; i < n; i++) {
            p[i] = rand.nextInt(n) + 1;
        }
        return p;
    }
}
