package ed;

public class Arvore {

    CelulaArvore raiz;

    public Arvore() {
        this.raiz = null;
    }

    public void insere(int valor) {
        this.raiz = this.insere(this.raiz, valor);
    }

    private CelulaArvore insere(CelulaArvore no, int valor) {
        if (no == null) {
            return new CelulaArvore(valor);
        }

        if (valor < no.getValor()) {
            no.setEsquerda(insere(no.getEsquerda(), valor));
        } else {
            no.setDireita(insere(no.getDireita(), valor));
        }
        return no;
    }

    private void imprime(CelulaArvore celula) {
        if (celula != null) {
            imprime(celula.getEsquerda());
            System.out.print(celula.getValor());
            System.out.print(" ");
            imprime(celula.getDireita());
        }
    }

    public CelulaArvore busca(int valor) {
        return this.busca(this.raiz, valor);
    }

    private CelulaArvore busca(CelulaArvore no, int valor) {
        // Implemente a busca aqui
    }

    public void imprime() {
        this.imprime(this.raiz);
        System.out.println();
    }
}
