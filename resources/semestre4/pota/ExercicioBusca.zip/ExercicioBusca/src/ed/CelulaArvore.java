package ed;

public class CelulaArvore {

    private int valor;
    private CelulaArvore esquerda;
    private CelulaArvore direita;

    public CelulaArvore() {
    }

    public CelulaArvore(int valor) {
        this.valor = valor;
        this.esquerda = null;
        this.direita = null;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return this.valor;
    }

    public void setEsquerda(CelulaArvore esquerda) {
        this.esquerda = esquerda;
    }

    public CelulaArvore getEsquerda() {
        return this.esquerda;
    }

    public void setDireita(CelulaArvore direita) {
        this.direita = direita;
    }

    public CelulaArvore getDireita() {
        return this.direita;
    }
}
