package ed;

public class CelulaLista {

    private int valor;
    private CelulaLista proximo;

    public CelulaLista() {
    }

    public CelulaLista(int valor) {
        this.valor = valor;
        this.proximo = null;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return this.valor;
    }

    public void setProximo(CelulaLista proximo) {
        this.proximo = proximo;
    }

    public CelulaLista getProximo() {
        return this.proximo;
    }
}
