package ed;

public class ListaEncadeada {

    private CelulaLista cabeca;

    public ListaEncadeada() {
        this.cabeca = null;
    }

    public void adicionaNoFim(int valor) {
        CelulaLista novo = new CelulaLista(valor);
        if (this.cabeca == null) {
            this.cabeca = novo;
        } else {
            CelulaLista ultimo = cabeca;
            while (ultimo.getProximo() != null) {
                ultimo = ultimo.getProximo();
            }
            ultimo.setProximo(novo);
        }
    }
    
    public CelulaLista busca(int valor) {
        return this.busca(this.cabeca, valor);
    }

    private CelulaLista busca(CelulaLista no, int valor) {
        // Implemente a busca aqui
    }

    public void imprime() {
        CelulaLista aux = this.cabeca;
        while (aux != null) {
            System.out.print(aux.getValor());
            System.out.print(" ");
            aux = aux.getProximo();
        }
        System.out.println();
    }
}
