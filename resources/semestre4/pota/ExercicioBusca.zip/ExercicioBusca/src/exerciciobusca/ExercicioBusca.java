package exerciciobusca;

import java.util.Random;
import ed.Arvore;
import ed.ListaEncadeada;

public class ExercicioBusca {

    public static void main(String[] args) {
        int n = 100;
        Random rnd = new Random();
        
        /********** Lista Encadeada **********/
        ListaEncadeada lista = new ListaEncadeada();
        
        // Adiciona 100 números aleatórios na lista encadeada
        for (int i = 0; i < n; i++) {
            int valor = rnd.nextInt(n);
            lista.adicionaNoFim(valor);
        }
        
        // Imprime a lista
        System.out.println("*** Lista Encadeada ***");
        lista.imprime();
        System.out.println();
        
        // Busca um elemento na lista
        // (Aqui você implementa)
        
        /********** Árvores **********/
        Arvore arv = new Arvore();
        
        // Adiciona 100 números aleatórios na árvore
        for (int i = 0; i < n; i++) {
            int valor = rnd.nextInt(n);
            arv.insere(valor);
        }
        
        // Imprime a árvore (em ordem)
        System.out.println("*** Árvore ***");
        arv.imprime();
        
        // Busca um elemento na árvore        
        int valor = 10;
        ed.CelulaArvore no = arv.busca(valor);
        boolean encontrou = (no != null && no.getValor() == valor);
        System.out.println("Encontrou o valor? " + encontrou);
    }    
}
