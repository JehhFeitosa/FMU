﻿# FMU
Atividades realizadas no período de estudos da Graduação de Análise e Desenvolvimento de Sistemas

## PACKAGE - PESQUISA, ORDENAÇÃO E TÉCNICAS DE ARMAZENAMENTO (P.O.T.A)
Aulas lecionadas pelo Mestre
em Engenharia da Informação (UFABC) "Orlando Junior"

## PACKAGE - SQL E NOSQL
Aulas lecionadas pelo Prof Ademir
