package Semestre_4_P.O.T.A_Aula08042021;


/*
 * Dado um vetor v de n posi��es, implemente um m�todo chamado 
 * contaNumeros para contar a quantidade de vezes que os n�meros 
 * desse vetor aparecem. Seu m�todo deve receber um vetor v como
 * entrada e devolver um vetor w cp, essa contagem
 */
public class TesteHash {

	public static void main(String[] args) {
		int[] v = {3,4,3,4,1,0,8};
	}
	
	public int[] contaNumeros(int[] v) {
		
		int[] w = null;
		
		for (int i = 0; i < v.length; i++) {
			//if(v[i].equals(w)) {
				
		//	}
			
		}
		
		return null;
		
	}

}
