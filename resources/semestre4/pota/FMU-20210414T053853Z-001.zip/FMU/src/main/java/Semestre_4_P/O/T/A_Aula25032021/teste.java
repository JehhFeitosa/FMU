package Semestre_4_P.O.T.A_Aula25032021;

public class teste {
	
	

	    public static void main(String[] args){
	        
	        int b = 0;

	        while(b <9){

	            System.out.println("La�o de repeti��o");
	            b++;


	       }
	    }

}
