package appexerciciosrecursividade;

public class AppExerciciosRecursividade {

    public static void main(String[] args) {
        // Maior valor
        int[] v = {1000, 41, 56, 89, 12, 9, 92, 87, 2000};
        int maior = maiorValor(v, v.length);
        System.out.println("Maior valor = " + maior);
    }

    public static int maiorValor(int[] v, int tamanho) {
        // Caso base
        if (tamanho == 1) {
            return v[0];
        } else {
            // Caso recursivo
            int maior = maiorValor(v, tamanho - 1);
            if (maior > v[tamanho - 1]) {
                return maior;
            }
            return v[tamanho - 1];
        }
    }
    
    public static float soma(float v[], int tamanho) {
        if (tamanho == 0) {
            return 0;
        }
        return v[tamanho - 1] + soma(v, tamanho - 1);
    }
}
