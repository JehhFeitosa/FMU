package apprecursividade;

public class AppRecursividade {

    public static void main(String[] args) {
        int n = 20;
        int fatorialIterativo = fatorialIterativo(n);
        int fatorialRecursivo = fatorialRecursivo(n);
        System.out.println("I - " + n + "! = " + fatorialIterativo);
        System.out.println("R - " + n + "! = " + fatorialRecursivo);
    }

    public static int fatorialIterativo(int n) {
        int fatorial = 1;
        for (int i = 1; i <= n; i++) {
            fatorial = fatorial * i;
        }
        return fatorial;
    }

    public static int fatorialRecursivo(int n) {
        if (n <= 1) {
            return 1;
        }
        return n * fatorialRecursivo(n - 1);
    }

    public static void exibeMensagem(String texto, int n) {
        if (n > 0) {
            System.out.println(texto);
            exibeMensagem(texto, n - 1);
        }
    }

    public static int soma(int x, int y) {
        int z;
        z = x + y;
        return z;
    }

}
